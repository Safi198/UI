package com.example.signature_forgery_detection

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
