import 'package:flutter/material.dart';

const tPrimaryColor = Color(0xFFFFE400);
const tSecondaryColor = Color(0xFF272727);
const tAncentColor = Color(0xFF001BFF);

const tWhiteColor = Colors.black;
const tDarkColor = Colors.black;
const tCardBgColor = Color(0xFFF7F6F1);



//onBoarding Colors

const tBoardingPage1Color = Colors.white;
const tBoardingPage2Color = Color(0xfffddcdf);
const tBoardingPage3Color = Color(0xffffdcbd);

