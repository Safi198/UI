

// App Default Settings
const tDefaultSize = 30.0;
const tButtonHeight = 15.0;
const tFormHeight = 30.0;

//Dashboard

const tDashBoardPadding = 20.0;
const tDashBoardCardPadding = 10.0;