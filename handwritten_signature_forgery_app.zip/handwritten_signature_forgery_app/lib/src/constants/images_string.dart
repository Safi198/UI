




//Onboard Images

const String tOnBoardingImage1 = "assets/images/onboard_images/onb1.png";

const String tOnBoardingImage2 = "assets/images/onboard_images/onb2.png";

const String tOnBoardingImage3 = "assets/images/onboard_images/onb3.png";

//Welcome image
const String tWelcomeScreenImage = "assets/images/welcome_image/wc.png";

//google log

const String tGoogleLogo = "assets/logo/g_icon.png";

//Forgot Password
const String tForgotPasswordImage = "assets/images/forgot_image/forgot.png";


//Dashboard
const String tUserProfileIcon = "assets/images/dashboard/Uprofile.png";

//Profile Pic
const String tUserProfilePic = "assets/images/profile_image/profile.jpeg";